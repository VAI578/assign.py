from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# Open Chrome browser
driver = webdriver.Chrome()

# Open Google
driver.get("https://www.google.com")

driver.maximize_window()

# Search data
search_box = driver.find_element(By.NAME, "q")
search_box.send_keys("Python Selenium")

search_box.submit()

time.sleep(3)

# Get page title
print("Page Title:", driver.title)

# Get headings data
headings = driver.find_elements(By.TAG_NAME, "h3")

print("\nSearch Results:\n")

for i, heading in enumerate(headings[:5], start=1):
    print(i, heading.text)

# Close browser
driver.quit()