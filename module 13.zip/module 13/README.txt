Assignment 12
Module 23: Automation using Selenium – Getting Data

This project uses Selenium automation to:
1. Open Google
2. Search "Python Selenium"
3. Extract search result headings
4. Print data in terminal